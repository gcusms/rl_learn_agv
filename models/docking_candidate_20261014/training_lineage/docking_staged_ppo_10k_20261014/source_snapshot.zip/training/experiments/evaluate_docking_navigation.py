"""Frozen development evaluation of learned terminal actor and localization."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import torch
from navrl.geometry import ROOT,wrap
from navrl.map import StaticMap
from neural_navigation.stress_env import StressNavigationEnv
from neural_navigation.masked_actions import ACTIONS,COMMANDS,masks_from_observation
from neural_navigation.experiment_budget import ExperimentBudget
from neural_navigation.goal_pose import contract
from experiments.docking_navigation import DockingRuntime
from experiments.goal_pose_navigation import GoalPoseRuntime


def additional_cases():
    cases=[];rng=np.random.default_rng(114980)
    for i in range(16):
        scene=ROOT/f'assets/navigation_stage2_dataset/train_{1+i%5:02d}'
        m=StaticMap(scene/'decision_map.yaml',radius=.3);cells=np.argwhere(m.clearance>.8)
        while True:
            xy=m.xy(cells[int(rng.integers(len(cells)))])
            yaw=float(rng.uniform(-np.pi,np.pi));distance=0. if i<8 else float(rng.uniform(.3,.7))
            goal=xy+distance*np.array([np.cos(yaw),np.sin(yaw)])
            if m.lookup(goal,m.clearance,outside=0)>.65 and m.visible(xy,goal):break
        offset=[0.,.12,-.12,.5,-.5,np.pi/2,-np.pi/2,np.pi][i%8]
        case=dict(id=f'docking_dev_{i:02d}',category='static',pilot_category='new_alignment' if i<8 else 'new_approach',
            seed=114980+i,scene=str(scene.relative_to(ROOT)),start=[*xy,yaw],
            goal=[*goal,float(wrap(yaw+offset))],odom_scale=1.,max_steps=150)
        if i in (6,14):case['extra_scan_dropout']=.08
        if i in (7,15):case['dropout_windows']=[[1.,1.4]]
        cases.append(case)
    return cases


def evaluate(case,bundle,budget):
    from collections import Counter
    import time
    scene=ROOT/case['scene'];env=StressNavigationEnv(case=case,components=bundle,
        scene_dir=scene,route_mode='shortcut',max_steps=case['max_steps'])
    try:
        options=dict(start=case['start'],goal=case['goal'][:2])
        if 'initial_prior_offset' in case:options['initial_prior_offset']=case['initial_prior_offset']
        env.reset(seed=case['seed'],options=options)
        manifest=json.loads((bundle/'manifest.json').read_text())
        runtime_class=DockingRuntime if 'docking_contract' in manifest else GoalPoseRuntime
        prior=np.asarray(case['start'])+np.asarray(case.get('initial_prior_offset',[0,0,0]))
        runtime=runtime_class(bundle,scene/'decision_map.yaml',prior,case['goal'],'shortcut')
        labels=[];observations=[];masks=[];choices=[];commands=[];stops=Counter();latencies=[]
        arrived=False;false_arrival=False;physical_since=None;c=contract();required=len(case['goal'])==3
        parity_frames=0
        for _ in range(case['max_steps']):
            start=time.perf_counter()
            result=runtime.step(env.scan,env.observed_odometry,env.measured_velocity,env.elapsed,capture_observation=True)
            latencies.append((time.perf_counter()-start)*1000)
            obs=np.asarray(result['policy_observation'],np.float32);mask=masks_from_observation(obs[:282])
            distances=np.max(abs(ACTIONS-np.asarray(result['proposed_action'])),axis=1);choice=int(distances.argmin())
            if distances[choice]>2e-6 or not mask[choice]:raise ValueError('Portable action/mask mismatch')
            if choice and result['stop_reason']!='estimated_goal_reached':np.testing.assert_allclose(result['command'],COMMANDS[choice],rtol=0,atol=2e-8)
            xy=float(np.linalg.norm(env.truth[:2]-case['goal'][:2]));yaw=float(abs(wrap(case['goal'][2]-env.truth[2]))) if required else 0.
            velocity=env._info('running')['actual_velocity']
            good=xy<(c['position_tolerance_m'] if required else .2) and (not required or (
                yaw<c['yaw_tolerance_rad'] and abs(velocity[0])<c['stopped_linear_m_s'] and abs(velocity[1])<c['stopped_angular_rad_s']))
            if not good:physical_since=None
            elif physical_since is None:physical_since=env.elapsed
            settled=not required or physical_since is not None and env.elapsed-physical_since>=c['settle_seconds']-1e-9
            labels.append([env.elapsed,*env.truth,*runtime.core.estimate,xy,yaw,*velocity])
            observations.append(obs);masks.append(mask);choices.append(choice);commands.append(result['command']);stops[str(result['stop_reason'])]+=1
            if result['stop_reason']=='estimated_goal_reached':
                if good and settled:arrived=True;break
                if not good:false_arrival=True;break
            env.step(np.asarray(result['command'])/[.2,.5]);budget.tick()
            if env.collision_events or env.hard_guard_activations:break
        protocol=not case.get('obstacle') or env.intervention is not None
        if 'reverse_after_event_s' in case:protocol=protocol and 'reversal_time_s' in (env.intervention or {})
        if 'actor_pause_after_event_s' in case:protocol=protocol and 'pause_completed_time_s' in (env.intervention or {})
        labels=np.array(labels);masks=np.array(masks);choices=np.array(choices)
        result=dict(case_id=case['id'],category=case['pilot_category'],safe_success=bool(arrived and protocol and not env.collision_events and not env.hard_guard_activations),
            physical_arrival=arrived,false_arrival=false_arrival,protocol_valid=bool(protocol),collisions=int(env.collision_events),
            physical_guards=int(env.hard_guard_activations),timeout=bool(not arrived and not false_arrival and not env.collision_events and not env.hard_guard_activations),
            seconds=float(env.elapsed),travel_m=float(env.travel),frames=len(choices),
            final_xy_error_m=float(labels[-1,7]),final_yaw_error_rad=float(labels[-1,8]) if required else None,
            localization_xy_p95_m=float(np.percentile(np.linalg.norm(labels[:,1:3]-labels[:,4:6],axis=1),95)),
            localization_yaw_p95_rad=float(np.percentile(abs(wrap(labels[:,3]-labels[:,6])),95)),
            stop_choices=int((choices==0).sum()),only_stop_frames=int((~masks[:,1:].any(axis=1)).sum()),stop_reasons=dict(stops),
            runtime_ms=dict(p95=float(np.percentile(latencies,95)),p99=float(np.percentile(latencies,99)),maximum=float(max(latencies))))
        return result,dict(labels=labels,observations=np.array(observations),masks=masks,choices=choices,commands=np.array(commands))
    finally:env.close()


def main():
    p=argparse.ArgumentParser();p.add_argument('--candidate',type=Path,required=True)
    p.add_argument('--baseline',type=Path);p.add_argument('--bc',type=Path);p.add_argument('--localized',type=Path)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--cases',type=Path)
    p.add_argument('--cpu-cores',type=float,default=.5);p.add_argument('--additional',action='store_true')
    a=p.parse_args()
    if a.output.exists():p.error('Fresh output required')
    a.output.mkdir(parents=True);torch.set_num_threads(1);budget=ExperimentBudget(a.cpu_cores,directory=a.output)
    cases=json.loads(a.cases.read_text()) if a.cases else additional_cases()
    if a.additional:cases+=additional_cases()
    case_file=a.output/'cases.json';case_file.write_text(json.dumps(cases,indent=2))
    report=dict(completed=False,scope='fixed development tasks; independent physical labels; not real deployment acceptance',
        deployment_approved=False,cases_sha256=hashlib.sha256(case_file.read_bytes()).hexdigest(),rows=[])
    for case in cases:
        variants=[('trained',a.candidate)]
        if a.baseline:variants.insert(0,('previous_3k',a.baseline))
        if a.bc and case['pilot_category']!='position_regression':variants.insert(0,('bc_only',a.bc))
        if a.localized:variants.append(('trained_v4_localization',a.localized))
        for variant,bundle in variants:
            result,trace=evaluate(case,bundle,budget);result['variant']=variant
            trace_path=a.output/f"{case['id']}_{variant}.npz";np.savez_compressed(trace_path,**trace)
            result['trace_sha256']=hashlib.sha256(trace_path.read_bytes()).hexdigest();report['rows'].append(result)
            report['resource']=budget.statistics();(a.output/'RESULTS.json').write_text(json.dumps(report,indent=2));print(json.dumps(result),flush=True)
    report['completed']=True;report['groups']={}
    for category in sorted(set(r['category'] for r in report['rows'])):
        report['groups'][category]={}
        for variant in sorted(set(r['variant'] for r in report['rows'])):
            rows=[r for r in report['rows'] if r['category']==category and r['variant']==variant]
            if rows:report['groups'][category][variant]=dict(tasks=len(rows),success=sum(r['safe_success'] for r in rows),
                collisions=sum(r['collisions'] for r in rows),timeouts=sum(r['timeout'] for r in rows),false_arrivals=sum(r['false_arrival'] for r in rows))
    (a.output/'RESULTS.json').write_text(json.dumps(report,indent=2));print(json.dumps(report['groups'],indent=2))


if __name__=='__main__':main()
