"""Protect the PPO/execution contract and the frozen navigation branch."""
import unittest
import gymnasium as gym
import numpy as np
import torch
from experiments.docking_navigation import DockingPolicy,PortableDockingActor,demonstration_choice
from neural_navigation.masked_actions import ACTIONS,masks_from_observation


class DockingTests(unittest.TestCase):
    def setUp(self):
        torch.set_num_threads(1);torch.manual_seed(9)
        self.policy=DockingPolicy(gym.spaces.Box(-1,1,(303,),np.float32),gym.spaces.Discrete(12),lambda _:1e-3)
        self.obs=torch.randn(24,303).clamp(-1,1)
        self.obs[:12,218:220]=.01;self.obs[:12,302]=1
        self.obs[12:18,218:220]=.2;self.obs[12:18,302]=1
        self.obs[18:,218:220]=.01;self.obs[18:,302]=0
        self.masks=masks_from_observation(self.obs[:,:282].numpy())

    def test_rollout_and_update_use_identical_masked_likelihood(self):
        action,value,old=self.policy(self.obs,action_masks=self.masks)
        new_value,new,entropy=self.policy.evaluate_actions(self.obs,action,action_masks=self.masks)
        torch.testing.assert_close(old,new,rtol=0,atol=0)
        torch.testing.assert_close(value,new_value,rtol=0,atol=0)
        self.assertTrue(np.all(self.masks[np.arange(len(action)),action.numpy()]))
        self.assertTrue(torch.isfinite(entropy).all())

    def test_learning_changes_terminal_branch_and_preserves_navigation(self):
        before=self.policy.logits(self.obs).detach().clone()
        loss=-self.policy.get_distribution(self.obs[:12],action_masks=self.masks[:12]).log_prob(torch.zeros(12,dtype=torch.long)).mean()
        self.policy.optimizer.zero_grad();loss.backward();self.policy.optimizer.step()
        after=self.policy.logits(self.obs).detach()
        torch.testing.assert_close(before[12:],after[12:],rtol=0,atol=0)
        self.assertGreater(float((before[:12]-after[:12]).abs().max()),0)

    def test_portable_has_identical_deterministic_choices(self):
        choice=self.policy.get_distribution(self.obs,action_masks=self.masks).get_actions(deterministic=True)
        with torch.no_grad():actual=PortableDockingActor(self.policy)(self.obs).numpy()
        np.testing.assert_array_equal(actual,ACTIONS[choice.numpy()])

    def test_reference_uses_heading_sign_and_keeps_stop_legal(self):
        obs=np.zeros(303,np.float32);obs[301]=1;mask=np.ones(12,bool)
        self.assertEqual(demonstration_choice(obs,mask),0)
        obs[300]=1;obs[301]=0;self.assertEqual(demonstration_choice(obs,mask),4)
        obs[300]=-1;self.assertEqual(demonstration_choice(obs,mask),5)
        mask[5]=False;self.assertEqual(demonstration_choice(obs,mask),0)

    def test_turn_response_is_opt_in_and_keeps_position_gate(self):
        from neural_navigation.odom_anchored_localizer import contract,turn_response_contract
        original=contract();candidate=turn_response_contract()
        self.assertEqual(original['maximum_yaw_rate_rad_s'],.06)
        self.assertEqual(candidate['maximum_yaw_rate_rad_s'],.15)
        for key in ('maximum_translation_rate_m_s','endpoint_gate_m','minimum_hits','minimum_support_fraction'):
            self.assertEqual(original[key],candidate[key])


if __name__=='__main__':unittest.main()
